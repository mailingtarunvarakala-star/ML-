# K-Means Clustering on Iris Dataset
# Includes Elbow Method and Silhouette Score

import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

iris = load_iris()
X = iris.data
feature_names = iris.feature_names

# Standardize features
X_scaled = StandardScaler().fit_transform(X)

# Elbow Method
inertias = []
k_values = range(2, 11)

for k in k_values:
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X_scaled)
    inertias.append(model.inertia_)

plt.figure()
plt.plot(list(k_values), inertias, marker="o")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method - Iris Dataset")
plt.grid(True)
plt.show()

# Silhouette Score
silhouette_scores = []

for k in k_values:
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = model.fit_predict(X_scaled)
    score = silhouette_score(X_scaled, labels)
    silhouette_scores.append(score)

plt.figure()
plt.plot(list(k_values), silhouette_scores, marker="o")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Silhouette Score")
plt.title("Silhouette Score - Iris Dataset")
plt.grid(True)
plt.show()

# Final K-Means model
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

print("K-Means Clustering")
print("------------------")
print("Number of clusters:", 3)
print("Silhouette Score:", round(silhouette_score(X_scaled, labels), 4))
print("Cluster counts:", __import__("numpy").bincount(labels))

# Visualization using first two standardized features
plt.figure()
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=labels)
plt.xlabel(feature_names[0])
plt.ylabel(feature_names[1])
plt.title("K-Means Clustering - Iris Dataset")
plt.show()
