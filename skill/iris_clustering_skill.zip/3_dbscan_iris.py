# DBSCAN Clustering on Iris Dataset

import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_iris
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

iris = load_iris()
X = iris.data

# Standardize features
X_scaled = StandardScaler().fit_transform(X)

# DBSCAN
model = DBSCAN(eps=0.8, min_samples=5)
labels = model.fit_predict(X_scaled)

n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
n_noise = np.sum(labels == -1)

print("DBSCAN Clustering")
print("-----------------")
print("Number of clusters:", n_clusters)
print("Number of noise points:", n_noise)

# Silhouette score is calculated only when there are at least 2 clusters
# and excludes noise points.
mask = labels != -1
if n_clusters >= 2 and len(set(labels[mask])) >= 2:
    score = silhouette_score(X_scaled[mask], labels[mask])
    print("Silhouette Score (excluding noise):", round(score, 4))
else:
    print("Silhouette Score: Not available for the detected clusters.")

plt.figure()
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=labels)
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.title("DBSCAN Clustering - Iris Dataset")
plt.show()
