# Skill Work - Iris Dataset

This repository contains four separate machine-learning programs using the built-in **Iris dataset** from scikit-learn.

## Programs

1. `1_kmeans_iris.py` - K-Means clustering with Elbow Method and Silhouette Score
2. `2_hierarchical_iris.py` - Hierarchical/Agglomerative clustering with dendrogram
3. `3_dbscan_iris.py` - DBSCAN clustering and noise detection
4. `4_pca_iris.py` - Principal Component Analysis (PCA)

## Requirements

```bash
pip install numpy matplotlib scikit-learn scipy
```

## Run

```bash
python3 1_kmeans_iris.py
python3 2_hierarchical_iris.py
python3 3_dbscan_iris.py
python3 4_pca_iris.py
```

No CSV file is required because the programs load the Iris dataset directly from `sklearn.datasets`.

## Dataset

The Iris dataset contains 150 samples and 4 numerical features:
- sepal length
- sepal width
- petal length
- petal width

The programs standardize the features before clustering/PCA.
