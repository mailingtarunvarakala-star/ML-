# Hierarchical Clustering on Iris Dataset

import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import dendrogram, linkage

iris = load_iris()
X = iris.data

# Standardize features
X_scaled = StandardScaler().fit_transform(X)

# Dendrogram
linked = linkage(X_scaled, method="ward")

plt.figure(figsize=(10, 5))
dendrogram(linked)
plt.title("Hierarchical Clustering Dendrogram - Iris Dataset")
plt.xlabel("Sample Index")
plt.ylabel("Distance")
plt.show()

# Agglomerative Hierarchical Clustering
model = AgglomerativeClustering(n_clusters=3, linkage="ward")
labels = model.fit_predict(X_scaled)

score = silhouette_score(X_scaled, labels)

print("Hierarchical Clustering")
print("-----------------------")
print("Number of clusters:", 3)
print("Silhouette Score:", round(score, 4))

plt.figure()
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=labels)
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.title("Hierarchical Clustering - Iris Dataset")
plt.show()
