import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

RANDOM_STATE = 42
CSV_FILE = "/content/placement_predict_50k_adjusted (1).csv"

NUMERIC_COLS = [
    "CGPA", "AttendancePercent", "Internships", "Projects", "Workshops",
    "Certifications", "Publications", "AptitudeTestScore", "SoftSkillsRating",
    "CodingTestScore", "MockInterviewScore",
]
CATEGORICAL_COLS = [
    "Gender", "City", "CollegeTier", "Stream", "Specialisation",
    "Hostel", "HistoryOfBacklogs", "ExtraCurricular",
]

def load_data():
    df = pd.read_csv(CSV_FILE)
    imputer = SimpleImputer(strategy="median")
    num_df = pd.DataFrame(
        imputer.fit_transform(df[NUMERIC_COLS]),
        columns=NUMERIC_COLS,
        index=df.index
    )
    cat_df = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=True)
    feature_df = pd.concat([num_df, cat_df], axis=1)
    X = StandardScaler().fit_transform(feature_df)
    return df, feature_df, X

from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

df, feature_df, X = load_data()
print("=" * 65)
print("DBSCAN CLUSTERING")
print("=" * 65)

# DBSCAN can become expensive on a very large dataset, so use a 5,000-row sample.
rng = np.random.RandomState(RANDOM_STATE)
sample_size = min(5000, len(X))
sample_idx = rng.choice(len(X), sample_size, replace=False)
X_sub = X[sample_idx]

# Parameters from the supplied program.
eps = 4.0
min_samples = 15

dbscan = DBSCAN(eps=eps, min_samples=min_samples)
labels = dbscan.fit_predict(X_sub)

n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
n_noise = int(np.sum(labels == -1))

print(f"Sample size: {sample_size}")
print(f"eps = {eps}")
print(f"min_samples = {min_samples}")
print(f"Number of clusters: {n_clusters}")
print(f"Noise points: {n_noise}")

if n_clusters >= 2:
    non_noise = labels != -1
    score = silhouette_score(X_sub[non_noise], labels[non_noise])
    print(f"Silhouette score (excluding noise): {score:.3f}")
else:
    print("Silhouette score was not calculated because DBSCAN found fewer than 2 clusters.")

# PCA visualization
from sklearn.decomposition import PCA
coords = PCA(n_components=2, random_state=RANDOM_STATE).fit_transform(X_sub)

plt.figure(figsize=(7, 5.5))
noise = labels == -1
plt.scatter(coords[~noise, 0], coords[~noise, 1],
            c=labels[~noise], cmap="tab10", s=8, alpha=0.6)
if np.any(noise):
    plt.scatter(coords[noise, 0], coords[noise, 1],
                c="lightgray", s=10, alpha=0.7, marker="x", label="Noise")
    plt.legend()
plt.title("DBSCAN Clustering")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()
plt.savefig("dbscan_pca.png", dpi=150)
plt.close()

# Save sampled results
result = df.iloc[sample_idx].copy()
result["DBSCANCluster"] = labels
result.to_csv("dbscan_clustered_students_sample.csv", index=False)

print("\nFiles created:")
print("- dbscan_pca.png")
print("- dbscan_clustered_students_sample.csv")
