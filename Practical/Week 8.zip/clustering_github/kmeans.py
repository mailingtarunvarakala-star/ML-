import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

RANDOM_STATE = 42
CSV_FILE = "/content/placement_predict_50k_adjusted (1).csv"

NUMERIC_COLS = [
    "CGPA", "AttendancePercent", "Internships", "Projects", "Workshops",
    "Certifications", "Publications", "AptitudeTestScore", "SoftSkillsRating",
    "CodingTestScore", "MockInterviewScore",
]
CATEGORICAL_COLS = [
    "Gender", "City", "CollegeTier", "Stream", "Specialisation",
    "Hostel", "HistoryOfBacklogs", "ExtraCurricular",
]

def load_data():
    df = pd.read_csv(CSV_FILE)
    imputer = SimpleImputer(strategy="median")
    num_df = pd.DataFrame(
        imputer.fit_transform(df[NUMERIC_COLS]),
        columns=NUMERIC_COLS,
        index=df.index
    )
    cat_df = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=True)
    feature_df = pd.concat([num_df, cat_df], axis=1)
    X = StandardScaler().fit_transform(feature_df)
    return df, feature_df, X

from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

df, feature_df, X = load_data()
print("=" * 65)
print("K-MEANS CLUSTERING - ELBOW METHOD + SILHOUETTE SCORE")
print("=" * 65)
print(f"Loaded {len(df):,} students and {X.shape[1]} features.")

# 1. Find a suitable k using Elbow and Silhouette methods
k_range = range(2, 9)
rng = np.random.RandomState(RANDOM_STATE)
sample_size = min(5000, len(X))
sample_idx = rng.choice(len(X), sample_size, replace=False)
X_sample = X[sample_idx]

inertias = []
silhouette_scores = []

for k in k_range:
    model = KMeans(n_clusters=k, n_init=10, random_state=RANDOM_STATE)
    labels = model.fit_predict(X)
    inertias.append(model.inertia_)
    silhouette_scores.append(
        silhouette_score(X_sample, model.predict(X_sample))
    )

best_k = list(k_range)[int(np.argmax(silhouette_scores))]

fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
axes[0].plot(list(k_range), inertias, marker="o")
axes[0].set_title("Elbow Method")
axes[0].set_xlabel("Number of clusters (k)")
axes[0].set_ylabel("Inertia")

axes[1].plot(list(k_range), silhouette_scores, marker="o")
axes[1].set_title("Silhouette Score")
axes[1].set_xlabel("Number of clusters (k)")
axes[1].set_ylabel("Silhouette Score")

plt.tight_layout()
plt.savefig("kmeans_elbow_silhouette.png", dpi=150)
plt.close(fig)

print("\nSilhouette scores:")
for k, score in zip(k_range, silhouette_scores):
    print(f"k={k}: {score:.3f}")
print(f"\nSilhouette-suggested k = {best_k}")

# 2. Train final K-Means model
kmeans = KMeans(n_clusters=best_k, n_init=10, random_state=RANDOM_STATE)
labels = kmeans.fit_predict(X)
final_silhouette = silhouette_score(X_sample, labels[sample_idx])

print(f"Final K-Means silhouette score: {final_silhouette:.3f}")
print("Cluster sizes:")
print(pd.Series(labels).value_counts().sort_index())

# 3. PCA visualization of K-Means clusters
from sklearn.decomposition import PCA
coords = PCA(n_components=2, random_state=RANDOM_STATE).fit_transform(X)

plt.figure(figsize=(7, 5.5))
plt.scatter(coords[:, 0], coords[:, 1], c=labels, cmap="tab10", s=8, alpha=0.6)
plt.title(f"K-Means Clusters (k={best_k})")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()
plt.savefig("kmeans_pca.png", dpi=150)
plt.close()

# 4. Save results
output = df.copy()
output["KMeansCluster"] = labels
output.to_csv("kmeans_clustered_students.csv", index=False)

print("\nFiles created:")
print("- kmeans_elbow_silhouette.png")
print("- kmeans_pca.png")
print("- kmeans_clustered_students.csv")
