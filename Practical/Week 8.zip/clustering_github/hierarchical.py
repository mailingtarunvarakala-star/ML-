import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

RANDOM_STATE = 42
CSV_FILE = "/content/placement_predict_50k_adjusted (1).csv"

NUMERIC_COLS = [
    "CGPA", "AttendancePercent", "Internships", "Projects", "Workshops",
    "Certifications", "Publications", "AptitudeTestScore", "SoftSkillsRating",
    "CodingTestScore", "MockInterviewScore",
]
CATEGORICAL_COLS = [
    "Gender", "City", "CollegeTier", "Stream", "Specialisation",
    "Hostel", "HistoryOfBacklogs", "ExtraCurricular",
]

def load_data():
    df = pd.read_csv(CSV_FILE)
    imputer = SimpleImputer(strategy="median")
    num_df = pd.DataFrame(
        imputer.fit_transform(df[NUMERIC_COLS]),
        columns=NUMERIC_COLS,
        index=df.index
    )
    cat_df = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=True)
    feature_df = pd.concat([num_df, cat_df], axis=1)
    X = StandardScaler().fit_transform(feature_df)
    return df, feature_df, X

from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import dendrogram, linkage

df, feature_df, X = load_data()
print("=" * 65)
print("HIERARCHICAL CLUSTERING")
print("=" * 65)

# Hierarchical clustering is O(n^2)-type work, so use a 5,000-row sample.
rng = np.random.RandomState(RANDOM_STATE)
sample_size = min(5000, len(X))
sample_idx = rng.choice(len(X), sample_size, replace=False)
X_sub = X[sample_idx]

# Use the same k-selection range as the original program.
k_range = range(2, 9)
scores = {}
for k in k_range:
    model = AgglomerativeClustering(n_clusters=k, linkage="ward")
    labels_k = model.fit_predict(X_sub)
    scores[k] = silhouette_score(X_sub, labels_k)

best_k = max(scores, key=scores.get)
model = AgglomerativeClustering(n_clusters=best_k, linkage="ward")
labels = model.fit_predict(X_sub)
score = silhouette_score(X_sub, labels)

print(f"Sample size: {sample_size}")
print("Silhouette scores:")
for k, s in scores.items():
    print(f"k={k}: {s:.3f}")
print(f"\nSelected k = {best_k}")
print(f"Hierarchical silhouette score: {score:.3f}")
print("Cluster sizes:")
print(pd.Series(labels).value_counts().sort_index())

# Dendrogram using a smaller sample for readability.
dendro_size = min(80, len(X_sub))
dendro_idx = rng.choice(len(X_sub), dendro_size, replace=False)
Z = linkage(X_sub[dendro_idx], method="ward")

plt.figure(figsize=(12, 5))
dendrogram(Z)
plt.title("Hierarchical Clustering Dendrogram (Ward Linkage)")
plt.xlabel("Student index")
plt.ylabel("Distance")
plt.tight_layout()
plt.savefig("hierarchical_dendrogram.png", dpi=150)
plt.close()

# PCA visualization
from sklearn.decomposition import PCA
coords = PCA(n_components=2, random_state=RANDOM_STATE).fit_transform(X_sub)

plt.figure(figsize=(7, 5.5))
plt.scatter(coords[:, 0], coords[:, 1], c=labels, cmap="tab10", s=8, alpha=0.6)
plt.title(f"Hierarchical Clustering (k={best_k})")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.tight_layout()
plt.savefig("hierarchical_pca.png", dpi=150)
plt.close()

# Save sampled results with original row index.
result = df.iloc[sample_idx].copy()
result["HierarchicalCluster"] = labels
result.to_csv("hierarchical_clustered_students_sample.csv", index=False)

print("\nFiles created:")
print("- hierarchical_dendrogram.png")
print("- hierarchical_pca.png")
print("- hierarchical_clustered_students_sample.csv")
