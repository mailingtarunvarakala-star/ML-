import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

RANDOM_STATE = 42
CSV_FILE = "/content/placement_predict_50k_adjusted (1).csv"

NUMERIC_COLS = [
    "CGPA", "AttendancePercent", "Internships", "Projects", "Workshops",
    "Certifications", "Publications", "AptitudeTestScore", "SoftSkillsRating",
    "CodingTestScore", "MockInterviewScore",
]
CATEGORICAL_COLS = [
    "Gender", "City", "CollegeTier", "Stream", "Specialisation",
    "Hostel", "HistoryOfBacklogs", "ExtraCurricular",
]

def load_data():
    df = pd.read_csv(CSV_FILE)
    imputer = SimpleImputer(strategy="median")
    num_df = pd.DataFrame(
        imputer.fit_transform(df[NUMERIC_COLS]),
        columns=NUMERIC_COLS,
        index=df.index
    )
    cat_df = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=True)
    feature_df = pd.concat([num_df, cat_df], axis=1)
    X = StandardScaler().fit_transform(feature_df)
    return df, feature_df, X

from sklearn.decomposition import PCA

df, feature_df, X = load_data()
print("=" * 65)
print("PRINCIPAL COMPONENT ANALYSIS (PCA)")
print("=" * 65)
print(f"Original number of features: {X.shape[1]}")

# Reduce the standardized feature space to 2 principal components.
pca_model = PCA(n_components=2, random_state=RANDOM_STATE)
X_pca = pca_model.fit_transform(X)

explained = pca_model.explained_variance_ratio_
print(f"PC1 explained variance: {explained[0] * 100:.2f}%")
print(f"PC2 explained variance: {explained[1] * 100:.2f}%")
print(f"Total explained variance: {explained.sum() * 100:.2f}%")

# Save transformed data
pca_output = pd.DataFrame(X_pca, columns=["PC1", "PC2"])
pca_output["OriginalIndex"] = df.index
pca_output.to_csv("pca_2_components.csv", index=False)

# Plot
plt.figure(figsize=(7, 5.5))
plt.scatter(X_pca[:, 0], X_pca[:, 1], s=8, alpha=0.6)
plt.title("PCA - 2D Projection")
plt.xlabel(f"PC1 ({explained[0] * 100:.2f}% variance)")
plt.ylabel(f"PC2 ({explained[1] * 100:.2f}% variance)")
plt.tight_layout()
plt.savefig("pca_2d.png", dpi=150)
plt.close()

print("\nFiles created:")
print("- pca_2_components.csv")
print("- pca_2d.png")
