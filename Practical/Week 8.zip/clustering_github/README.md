# Student Clustering and PCA

This repository contains the original clustering work split into four separate Python programs:

1. `kmeans.py` — K-Means with Elbow Method and Silhouette Score
2. `hierarchical.py` — Hierarchical (Agglomerative) Clustering with Ward linkage and dendrogram
3. `dbscan.py` — DBSCAN clustering with noise detection and silhouette score
4. `pca.py` — Principal Component Analysis for 2D dimensionality reduction

## Dataset

The programs expect the dataset:

`placement_predict_50k_adjusted (1).csv`

The original program uses the following numeric and categorical columns and excludes `PlacementStatus` and `IsAnomaly` from clustering features.

> Change `CSV_FILE` in each `.py` file if your CSV is stored somewhere else.

## Install libraries

```bash
pip install numpy pandas matplotlib scikit-learn scipy
```

## Run

```bash
python kmeans.py
python hierarchical.py
python dbscan.py
python pca.py
```

If using Google Colab, keep the `/content/...csv` path or upload the CSV to `/content`.

## Generated output

### K-Means
- `kmeans_elbow_silhouette.png`
- `kmeans_pca.png`
- `kmeans_clustered_students.csv`

### Hierarchical
- `hierarchical_dendrogram.png`
- `hierarchical_pca.png`
- `hierarchical_clustered_students_sample.csv`

### DBSCAN
- `dbscan_pca.png`
- `dbscan_clustered_students_sample.csv`

### PCA
- `pca_2_components.csv`
- `pca_2d.png`

## Note

Hierarchical clustering and DBSCAN are run on a maximum 5,000-row sample, following the approach of the supplied program so that these methods remain practical for a large 50k-row dataset. K-Means and PCA use the full dataset.
